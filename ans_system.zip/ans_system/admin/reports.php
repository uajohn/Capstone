<?php 
    include("../assets/connection/connection.php");
    include("../universal/ad_cookie.php");
    include("../universal/session.php");
?>

<!DOCTYPE html>
<html lang="en">

    <?php include("../universal/head.php");?>

    <body>
        <?php include("../universal/top_nav.php");?>
        <?php include("../universal/ad_left_nav.php");?>

        <section class="section-content">

        </section>
    </body>
</html>