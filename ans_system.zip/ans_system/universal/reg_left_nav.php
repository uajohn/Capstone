<header class="header-left">
    <nav>
        <ul>
            <a href="./enroll_student.php">
                <li enroll_student-php><img src="../assets/icons/students.svg" alt="users">Enroll Student</li>
            </a>           
            <a href="./encode_grades.php">
                <li encode_grades-php><img src="../assets/icons/grades.svg" alt="users">Encode Grades</li>
            </a>
            <a href="./reports.php">
                <li reports-php><img src="../assets/icons/reports.svg" alt="reports">Reports</li>
            </a>
        </ul>
    </nav>

</header>