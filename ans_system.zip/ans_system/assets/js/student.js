function viewDetailCta(){
    _query(".update-enrollment").showModal();
}
//view info
function viewDetailCta(id){
    const x = new XMLHttpRequest();
    x.onload = function(){
        _elementId("updateStudents").innerHTML = this.responseText;
        _query(".update-enrollment").showModal();
    }
    x.open("GET","../student_re/view_reports.php?studentId="+encodeURIComponent(id));
    x.send();

}
function printFormCta(){
    _query(".print-form").showModal();
}