<header class="header-left">
    <nav>
        <ul>
            <a href="./view_reports.php">
                <li view_reports-php><img src="../assets/icons/students.svg" alt="users">View reports</li>
            </a>           
            <a href="./view_grades.php">
                <li view_grades-php><img src="../assets/icons/grades.svg" alt="users">View grades</li>
            </a>
        </ul>
    </nav>
</header>