<header class="header-left">
    <nav>
        <ul>
            <a href="./user_accounts.php">
                <li user_accounts-php><img src="../assets/icons/users.svg" alt="users">User Account</li>
            </a>
            <!-- <a href="./students.php">
                <li students-php><img src="../assets/icons/students.svg" alt="students">Students</li>
            </a>
            <a href="./reports.php">
                <li reports-php><img src="../assets/icons/reports.svg" alt="reports">Reports</li>
            </a> -->
        </ul>
    </nav>

</header>