<?php
    include("../assets/connection/connection.php"); 
    session_start();

     //add new Subjects
    if(isset($_POST['newSubject'])){

        $newSubject = mysqli_real_escape_string($conn, $_POST['newSubject']);

        //check if name exists already
        $sql = "SELECT * FROM `subjects` WHERE `subject_name`='$newSubject';";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0){
            echo "Subject already exists";
        }
        else{
            $query = mysqli_query($conn,"INSERT INTO `subjects`(`subject_name`) VALUES('$newSubject');");
        }

    }
     //search Name for grade
     if(isset($_GET['filterName']) && isset($_GET['searchName']) && isset($_GET['entriesName'])){
        $filterName = mysqli_real_escape_string($conn,$_GET['filterName']);
        $searchName = mysqli_real_escape_string($conn,$_GET['searchName']);
        $entriesName = $_GET['entriesName'];
        
        //if filter is empty
        if($filterName === ""){
            $sql = "SELECT * FROM `students` INNER JOIN `details` ON `students`.`student_id`=`details`.`student_id` INNER JOIN `school_year` ON `details`.`school_year_id`=`school_year`.`school_year_id` WHERE CONCAT(`first_name`,`last_name`) LIKE '%$searchName%' ORDER BY `students`.`student_id` ASC ";
            $_SESSION['conditionName'] = "WHERE CONCAT(`first_name`,`last_name`) LIKE '%$searchName%' ORDER BY `students`.`student_id` ASC ";
        }
        //if filter has value
        else{
            $sql = "SELECT * FROM `students` INNER JOIN `details` ON `students`.`student_id`=`details`.`student_id` INNER JOIN `school_year` ON `details`.`school_year_id`=`school_year`.`school_year_id` WHERE $filterName LIKE '%$searchName%' ORDER BY `students`.`student_id` ASC ";
            $_SESSION['conditionName'] = "WHERE $filterName LIKE '%$searchName%'";
        }
        $_SESSION['searchName'] = $sql;
        $_SESSION['pageNoName'] = 1;

        //refresh table
        tableName(1,$entriesName);
    }
        //previous page
        if(isset($_GET['prevPage']) && isset($_GET['entriesName'])){
            tableName($_GET['prevPage'],$_GET['entriesName']);
            $_SESSION['pageNoName'] = $_GET['prevPage'];
        }
    
        //next page
        if(isset($_GET['nextPage']) && isset($_GET['entriesName'])){
            tableName($_GET['nextPage'],$_GET['entriesName']);
            $_SESSION['pageNoName'] = $_GET['nextPage'];
        }
    
        //show entries per page
        if(isset($_GET['entriesName']) && isset($_GET['showPerPage'])){
            tableName(1,$_GET['entriesName']);
        }
    
    //table name
        function tableName($pageNo,$entriesName){
            include("../assets/connection/connection.php");
            ?>
    
            <div class="table-data">
                <table>
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>#</th>
                            <th>Schoolyear</th>
                            <th>Firstname</th>
                            <th>Middlename</th>
                            <th>Lastname</th>
                            <th>Address</th>
                            <th>Yearlevel</th>
                            <th>section</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                            $entriesPerPage = $entriesName;
                            $offset = ($pageNo - 1) * $entriesPerPage;
                            $prevPage = $pageNo - 1;
                            $nextPage = $pageNo + 1;
    
                            //search session set
                            if(isset($_SESSION['searchName'])){
                                $conditionName = $_SESSION['conditionName'];
                                $countAllEntries = mysqli_query($conn, "SELECT COUNT(*) as total_records FROM `students` $conditionName;");
                                $records = mysqli_fetch_array($countAllEntries);
                                $totalRecords = $records['total_records'];
                                $noOfPages = ceil($totalRecords / $entriesPerPage);
                                $sql = $_SESSION['searchName'] . " LIMIT $offset, $entriesPerPage;";
                            }
                            //not set
                            else{
                                $countAllEntries = mysqli_query($conn, "SELECT COUNT(*) as total_records FROM `students`;");
                                $records = mysqli_fetch_array($countAllEntries);
                                $totalRecords = $records['total_records'];
                                $noOfPages = ceil($totalRecords / $entriesPerPage);
                                $sql = "SELECT * FROM `students` INNER JOIN `details` ON `students`.`student_id`=`details`.`student_id` INNER JOIN `school_year` ON `details`.`school_year_id`=`school_year`.`school_year_id` ORDER BY `students`.`student_id` ASC LIMIT $offset, $entriesPerPage;";
                            }
                            $query = mysqli_query($conn,$sql);
    
                            if(mysqli_num_rows($query)>0){
                                while($rows = mysqli_fetch_assoc($query)){?>
                                    <tr>
                                        <td class="td-action">
                                            <img src="../assets/icons/edit.svg" onclick="updateStudentGrades1Cta(<?php echo $rows['student_id'] ?>)">
                                            <span>|</span>
                                            <img src="../assets/icons/edit.svg" onclick="updateStudentGrades2Cta(<?php echo $rows['student_id'] ?>)">
                                            <span>|</span>
                                            <img src="../assets/icons/edit.svg" onclick="updateStudentGrades3Cta(<?php echo $rows['student_id'] ?>)">
                                            <span>|</span>
                                            <img src="../assets/icons/edit.svg" onclick="updateStudentGrades4Cta(<?php echo $rows['student_id'] ?>)">
                                        </td>
                                        <td><?php echo $rows['student_id']?></td>
                                        <td><?php echo $rows['school_year_value']?></td>
                                        <td><?php echo $rows['first_name']?></td>
                                        <td><?php echo $rows['middle_name']?></td>
                                        <td><?php echo $rows['last_name']?></td>
                                        <td><?php echo $rows['year_level']?></td>
                                        <td><?php echo $rows['section']?></td>
                                                
                                                
                                    </tr><?php
                                }
                            }
                            else{
                                echo "<tr><td colspan='9'>No results or no data in the table</td></tr>";
                                $pageNo = 0;
                            }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="pagination">
                <aside>
                    <p id="pageOfPage">Page <?php echo $pageNo?> of <?php echo $noOfPages?></p>
                </aside>
                <aside>
                    <?php
                        //buttons prev
                        if($pageNo <= 1){?>
                            <button type="button" class="button-disabled" disabled>Previous</button><?php
                        }
                        else{?>
                            <button type="button" onclick="prevPageNameCta(<?php echo $prevPage?>)">Previous</button><?php
                        }
    
                        //button next
    
                        if($pageNo >= $noOfPages){?>
                            <button type="button" class="button-disabled" disabled>Next</button><?php
                        }
                        else{?>
                            <button type="button" onclick="nextPageNameCta(<?php echo $nextPage?>)">Next</button><?php
                        }
                    ?>
                    
                    
                </aside>
            </div><?php
        }
    //  //for search student name1
    if(isset($_GET['searchStudentName'])){
        $studentName = mysqli_real_escape_string($conn,$_GET['searchStudentName']);
        $sql = "SELECT `student_id`, CONCAT(`first_name`,`middle_name`,`last_name`,`suffix`) AS 'full_name' FROM `students` WHERE CONCAT(`first_name`,`middle_name`,`last_name`,`suffix`) LIKE '%$studentName%';";
        
        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query)>0){
            while($rows = mysqli_fetch_array($query)){
                $studentId = $rows['student_id'];
                $fullname = $rows['full_name'];?>
                <p id="studentResult" onclick="studentInfoIdCta(<?php echo $studentId?>)"><?php echo $fullname?></p><?php
            }
        }
    }
    if(isset($_GET['studentId'])){
        $id = $_GET['studentId'];
        $query = mysqli_query($conn, "SELECT CONCAT(`first_name`,' ',`middle_name`,' ',`last_name`,' ',`suffix`) AS 'fullname' FROM `students` WHERE `student_id`=$id;");

        if(mysqli_num_rows($query)>0){
            $rows = mysqli_fetch_assoc($query);?>
            <p>Enter grade:</p>
            <div>
                <label for="studentname">Name:</label>
                <input type="text" id="studentname" value="<?php echo $rows['fullname']?>" readonly>
            </div>
                <div>
                    <label for="subjectEnglish">English:</label>
                    <input type="text" id="subjectEnglish">
                </div>
                <div>
                    <label for="subjectFilipino">Filipino:</label>
                    <input type="text" id="subjectFilipino">
                </div>
                <div>
                    <label for="subjectMath">Math:</label>
                    <input type="text" id="subjectMath">
                </div>
                <div>
                    <label for="subjectScience">Science:</label>
                    <input type="text" id="subjectScience">
                </div>
                <div>
                    <label for="subjectAP">Araling Panlipunan:</label>
                    <input type="text" id="subjectAP">
                </div>
                <div>
                    <label for="subjectEsp">Edukasyon sa Pagpapakatao:</label>
                    <input type="text" id="subjectEsp">
                </div>
                <div>
                    <label for="subjectTle">Technology and Livelihood Education:</label>
                    <input type="text" id="subjectTle">
                </div>
                <div>
                    <label for="subjectMapeh">Mapeh:</label>
                    <input type="text" id="subjectMusic" placeholder="Music">
                    <input type="text" id="subjectArts" placeholder="Arts">
                    <input type="text" id="subjectPe" placeholder="Pe">
                    <input type="text" id="subjectHealth" placeholder="Health">
                </div>
                <button type="button" onclick="submitFirstgradingCta()"><img src="../assets/icons/save.svg" alt="save">Submit</button>  
            </div><?php
        }
    }
         //for search student name3
     if(isset($_GET['searchStudentName2'])){
         $studentName2 = mysqli_real_escape_string($conn,$_GET['searchStudentName2']);
         $sql = "SELECT `student_id`, CONCAT(`first_name`,`middle_name`,`last_name`,`suffix`) AS 'full_name' FROM `students` WHERE CONCAT(`first_name`,`middle_name`,`last_name`,`suffix`) LIKE '%$studentName2%';";
        
         $query = mysqli_query($conn,$sql);

         if(mysqli_num_rows($query)>0){
             while($rows = mysqli_fetch_array($query)){
                 $studentId2 = $rows['student_id'];
                 $fullname = $rows['full_name'];?>
                 <p id="studentResult2" onclick="studentInfoId2Cta(<?php echo $studentId2?>)"><?php echo $fullname?></p><?php
             }
         }
     }
     if(isset($_GET['studentId2'])){
         $id = $_GET['studentId2'];
         $query = mysqli_query($conn, "SELECT CONCAT(`first_name`,' ',`middle_name`,' ',`last_name`,' ',`suffix`) AS 'fullname' FROM `students` WHERE `student_id`=$id;");

         if(mysqli_num_rows($query)>0){
             $rows = mysqli_fetch_assoc($query);?>

             <div>
                 <label for="studentname">Name:</label>
                 <input type="text" id="studentname2" value="<?php echo $rows['fullname']?>" readonly>
             </div>
                 <div>
                     <label for="subjectEnglish">English:</label>
                     <input type="text" id="subjectEnglish2">
                 </div>
                 <div>
                     <label for="subjectFilipino">Filipino:</label>
                     <input type="text" id="subjectFilipino2">
                 </div>
                 <div>
                     <label for="subjectMath">Math:</label>
                     <input type="text" id="subjectMath2">
                 </div>
                 <div>
                     <label for="subjectScience">Science:</label>
                     <input type="text" id="subjectScience2">
                 </div>
                 <div>
                     <label for="subjectAP">Araling Panlipunan:</label>
                     <input type="text" id="subjectAP2">
                 </div>
                 <div>
                     <label for="subjectEsp">Edukasyon sa Pagpapakatao:</label>
                     <input type="text" id="subjectEsp2">
                 </div>
                 <div>
                     <label for="subjectTle">Technology and Livelihood Education:</label>
                     <input type="text" id="subjectTle2">
                 </div>
                 <div>
                     <label for="subjectMapeh">Mapeh:</label>
                     <input type="text" id="subjectMusic2" placeholder="Music">
                     <input type="text" id="subjectArts2" placeholder="Arts">
                     <input type="text" id="subjectPe2" placeholder="Pe">
                     <input type="text" id="subjectHealth2" placeholder="Health">
                 </div>
                 <button type="button" onclick="submitSecondgradingCta()"><img src="../assets/icons/save.svg" alt="save">Submit</button>  
             </div><?php
        }
     }
    //for search student name2
    if(isset($_GET['searchStudentName3'])){
         $studentName3 = mysqli_real_escape_string($conn,$_GET['searchStudentName3']);
         $sql = "SELECT `student_id`, CONCAT(`first_name`,`middle_name`,`last_name`,`suffix`) AS 'full_name' FROM `students` WHERE CONCAT(`first_name`,`middle_name`,`last_name`,`suffix`) LIKE '%$studentName3%';";
        
        $query = mysqli_query($conn,$sql);

         if(mysqli_num_rows($query)>0){
            while($rows = mysqli_fetch_array($query)){
                 $studentId3 = $rows['student_id'];
                 $fullname = $rows['full_name'];?>
                 <p id="studentResult3" onclick="studentInfoId3Cta(<?php echo $studentId3?>)"><?php echo $fullname?></p><?php
             }
         }
     }
    if(isset($_GET['studentId3'])){
         $id = $_GET['studentId3'];
         $query = mysqli_query($conn, "SELECT CONCAT(`first_name`,' ',`middle_name`,' ',`last_name`,' ',`suffix`) AS 'fullname' FROM `students` WHERE `student_id`=$id;");

         if(mysqli_num_rows($query)>0){
             $rows = mysqli_fetch_assoc($query);?>

             <div>
                 <label for="studentname">Name:</label>
                 <input type="text" id="studentname3" value="<?php echo $rows['fullname']?>" readonly>
             </div>
             <div>
                 <label for="subjectEnglish">English:</label>
                 <input type="text" id="subjectEnglish3">
             </div>
             <div>
                 <label for="subjectFilipino">Filipino:</label>
                 <input type="text" id="subjectFilipino3">
             </div>
             <div>
                     <label for="subjectMath">Math:</label>
                     <input type="text" id="subjectMath3">
                 </div>
                 <div>
                     <label for="subjectScience">Science:</label>
                     <input type="text" id="subjectScience3">
                 </div>
                 <div>
                     <label for="subjectAP">Araling Panlipunan:</label>
                     <input type="text" id="subjectAP3">
                 </div>
                 <div>
                     <label for="subjectEsp">Edukasyon sa Pagpapakatao:</label>
                     <input type="text" id="subjectEsp3">
                 </div>
                 <div>
                     <label for="subjectTle">Technology and Livelihood Education:</label>
                     <input type="text" id="subjectTle3">
                 </div>
                 <div>
                    <label for="subjectMapeh">Mapeh:</label>
                     <input type="text" id="subjectMusic3" placeholder="Music">
                     <input type="text" id="subjectArts3" placeholder="Arts">
                     <input type="text" id="subjectPe3" placeholder="Pe">
                     <input type="text" id="subjectHealth3" placeholder="Health">
                 </div>
                 <button type="button" onclick="submitThirdgradingCta()"><img src="../assets/icons/save.svg" alt="save">Submit</button>  
             </div><?php
         }
     }
      //for search student name4
      if(isset($_GET['searchStudentName4'])){
         $studentName4 = mysqli_real_escape_string($conn,$_GET['searchStudentName4']);
         $sql = "SELECT `student_id`, CONCAT(`first_name`,`middle_name`,`last_name`,`suffix`) AS 'full_name' FROM `students` WHERE CONCAT(`first_name`,`middle_name`,`last_name`,`suffix`) LIKE '%$studentName4%';";
        
         $query = mysqli_query($conn,$sql);

         if(mysqli_num_rows($query)>0){
             while($rows = mysqli_fetch_array($query)){
                 $studentId4 = $rows['student_id'];
                 $fullname = $rows['full_name'];?>
                 <p id="studentResult4" onclick="studentInfoId4Cta(<?php echo $studentId4?>)"><?php echo $fullname?></p><?php
             }
         }
     }
     if(isset($_GET['studentId4'])){
         $id = $_GET['studentId4'];
         $query = mysqli_query($conn, "SELECT CONCAT(`first_name`,' ',`middle_name`,' ',`last_name`,' ',`suffix`) AS 'fullname' FROM `students` WHERE `student_id`=$id;");

         if(mysqli_num_rows($query)>0){
             $rows = mysqli_fetch_assoc($query);?>

             <div>
                 <label for="studentname">Name:</label>
                 <input type="text" id="studentname4" value="<?php echo $rows['fullname']?>" readonly>
             </div>
                 <div>
                     <label for="subjectEnglish">English:</label>
                     <input type="text" id="subjectEnglish4">
                 </div>
                 <div>
                     <label for="subjectFilipino">Filipino:</label>
                     <input type="text" id="subjectFilipino4">
                 </div>
                 <div>
                     <label for="subjectMath">Math:</label>
                     <input type="text" id="subjectMath4">
                 </div>
                 <div>
                     <label for="subjectScience">Science:</label>
                     <input type="text" id="subjectScience4">
                 </div>
                 <div>
                     <label for="subjectAP">Araling Panlipunan:</label>
                     <input type="text" id="subjectAP4">
                 </div>
                 <div>
                     <label for="subjectEsp">Edukasyon sa Pagpapakatao:</label>
                     <input type="text" id="subjectEsp4">
                 </div>
                 <div>
                     <label for="subjectTle">Technology and Livelihood Education:</label>
                  <input type="text" id="subjectTle4">
                </div>
                <div>
                     <label for="subjectMapeh">Mapeh:</label>
                     <input type="text" id="subjectMusic4" placeholder="Music">
                     <input type="text" id="subjectArts4" placeholder="Arts">
                    <input type="text" id="subjectPe4" placeholder="Pe">
                    <input type="text" id="subjectHealth4" placeholder="Health">
                 </div>
                 <button type="button" onclick="submitFourthgradingCta()"><img src="../assets/icons/save.svg" alt="save">Submit</button>  
            </div><?php
         }
     }

    //submit first grading grade
    if(isset($_POST['subjectEnglish'])&& isset($_POST['studentId']) && isset($_POST['subjectFilipino'])&& isset($_POST['subjectMath'])&& isset($_POST['subjectScience'])&& isset($_POST['subjectAP'])&& isset($_POST['subjectEsp'])&& isset($_POST['subjectTle'])&& isset($_POST['subjectMusic'])&& isset($_POST['subjectArts'])&& isset($_POST['subjectPe'])&& isset($_POST['subjectHealth'])){
        $studentId = mysqli_real_escape_string($conn, $_POST['studentId']);
        $subjectEnglish = mysqli_real_escape_string($conn, $_POST['subjectEnglish']);
        $subjectFilipino = mysqli_real_escape_string($conn, $_POST['subjectFilipino']);
        $subjectMath = mysqli_real_escape_string($conn, $_POST['subjectMath']);
        $subjectScience = mysqli_real_escape_string($conn, $_POST['subjectScience']);
        $subjectAP = mysqli_real_escape_string($conn, $_POST['subjectAP']);
        $subjectEsp = mysqli_real_escape_string($conn, $_POST['subjectEsp']);
        $subjectTle = mysqli_real_escape_string($conn, $_POST['subjectTle']);
        $subjectMusic = mysqli_real_escape_string($conn, $_POST['subjectMusic']);
        $subjectArts = mysqli_real_escape_string($conn, $_POST['subjectArts']);
        $subjectPe = mysqli_real_escape_string($conn, $_POST['subjectPe']);
        $subjectHealth = mysqli_real_escape_string($conn, $_POST['subjectHealth']);
    
        // Check if student grades already exist
        // $sql = mysqli_query($conn, "SELECT * FROM `first_grading` WHERE `english`='$subjectEnglish' AND `filipino`='$subjectFilipino' AND `math`='$subjectMath' AND `science`='$subjectScience' AND `ap`='$subjectAP' AND `esp`='$subjectEsp' AND `tle`='$subjectTle' AND `music`='$subjectMusic' AND `art`='$subjectArts' AND `pe`='$subjectPe' AND `health`='$subjectHealth' AND `student_id`='$studentInfoIdCta';");
        // $result = mysqli_query($conn, $sql); 
        // if (mysqli_num_rows($result) >0) {
        //     echo "Grades already exist";
        // } 
        // else{  
            
            // Add grade
            mysqli_query($conn, "INSERT INTO `first_grading`(`english`, `filipino`, `math`, `science`, `ap`, `esp`, `tle`, `music`, `art`, `pe`, `health` , `student_id`) VALUES ('$subjectEnglish','$subjectFilipino','$subjectMath','$subjectScience','$subjectAP','$subjectEsp','$subjectTle','$subjectMusic','$subjectArts','$subjectPe','$subjectHealth',$studentId);");
        }
    // }
      //submit second grading grade
      if(isset($_POST['subjectEnglish2'])&& isset($_POST['studentId2']) && isset($_POST['subjectFilipino2'])&& isset($_POST['subjectMath2'])&& isset($_POST['subjectScience2'])&& isset($_POST['subjectAP2'])&& isset($_POST['subjectEsp2'])&& isset($_POST['subjectTle2'])&& isset($_POST['subjectMusic2'])&& isset($_POST['subjectArts2'])&& isset($_POST['subjectPe2'])&& isset($_POST['subjectHealth2'])){
        $studentId2 = mysqli_real_escape_string($conn, $_POST['studentId2']);
        $subjectEnglish2 = mysqli_real_escape_string($conn, $_POST['subjectEnglish2']);
        $subjectFilipino2 = mysqli_real_escape_string($conn, $_POST['subjectFilipino2']);
        $subjectMath2 = mysqli_real_escape_string($conn, $_POST['subjectMath2']);
        $subjectScience2 = mysqli_real_escape_string($conn, $_POST['subjectScience2']);
        $subjectAP2 = mysqli_real_escape_string($conn, $_POST['subjectAP2']);
        $subjectEsp2 = mysqli_real_escape_string($conn, $_POST['subjectEsp2']);
        $subjectTle2 = mysqli_real_escape_string($conn, $_POST['subjectTle2']);
        $subjectMusic2 = mysqli_real_escape_string($conn, $_POST['subjectMusic2']);
        $subjectArts2 = mysqli_real_escape_string($conn, $_POST['subjectArts2']);
        $subjectPe2 = mysqli_real_escape_string($conn, $_POST['subjectPe2']);
        $subjectHealth2 = mysqli_real_escape_string($conn, $_POST['subjectHealth2']);
    
        // Check if student grades already exist
        // $sql = mysqli_query($conn, "SELECT * FROM `first_grading` WHERE `english`='$subjectEnglish2' AND `filipino`='$subjectFilipino2' AND `math`='$subjectMath2' AND `science`='$subjectScience2' AND `ap`='$subjectAP2' AND `esp`='$subjectEsp2' AND `tle`='$subjectTle2' AND `music`='$subjectMusic2' AND `art`='$subjectArts2' AND `pe`='$subjectPe2' AND `health`='$subjectHealth2' AND `student_id`='$studentInfoIdCta';");
        // $result = mysqli_query($conn, $sql); 
        // if (mysqli_num_rows($result) >0) {
        //     echo "Grades already exist";
        // } 
        // else{  
            
            // Add grade
            mysqli_query($conn, "INSERT INTO `second_grading`(`english2`, `filipino2`, `math2`, `science2`, `ap2`, `esp2`, `tle2`, `music2`, `art2`, `pe2`, `health2` , `student_id`) VALUES ('$subjectEnglish2','$subjectFilipino2','$subjectMath2','$subjectScience2','$subjectAP2','$subjectEsp2','$subjectTle2','$subjectMusic2','$subjectArts2','$subjectPe2','$subjectHealth2',$studentId2);");
        }
    // }
     //submit third grading grade
     if(isset($_POST['subjectEnglish3'])&& isset($_POST['studentId3']) && isset($_POST['subjectFilipino3'])&& isset($_POST['subjectMath3'])&& isset($_POST['subjectScience3'])&& isset($_POST['subjectAP3'])&& isset($_POST['subjectEsp3'])&& isset($_POST['subjectTle3'])&& isset($_POST['subjectMusic3'])&& isset($_POST['subjectArts3'])&& isset($_POST['subjectPe3'])&& isset($_POST['subjectHealth3'])){
        $studentId3 = mysqli_real_escape_string($conn, $_POST['studentId3']);
        $subjectEnglish3 = mysqli_real_escape_string($conn, $_POST['subjectEnglish3']);
        $subjectFilipino3 = mysqli_real_escape_string($conn, $_POST['subjectFilipino3']);
        $subjectMath3 = mysqli_real_escape_string($conn, $_POST['subjectMath3']);
        $subjectScience3 = mysqli_real_escape_string($conn, $_POST['subjectScience3']);
        $subjectAP3 = mysqli_real_escape_string($conn, $_POST['subjectAP3']);
        $subjectEsp3 = mysqli_real_escape_string($conn, $_POST['subjectEsp3']);
        $subjectTle3 = mysqli_real_escape_string($conn, $_POST['subjectTle3']);
        $subjectMusic3 = mysqli_real_escape_string($conn, $_POST['subjectMusic3']);
        $subjectArts3 = mysqli_real_escape_string($conn, $_POST['subjectArts3']);
        $subjectPe3 = mysqli_real_escape_string($conn, $_POST['subjectPe3']);
        $subjectHealth3 = mysqli_real_escape_string($conn, $_POST['subjectHealth3']);
    
        // Check if student grades already exist
        // $sql = mysqli_query($conn, "SELECT * FROM `first_grading` WHERE `english`='$subjectEnglish3' AND `filipino`='$subjectFilipino3' AND `math`='$subjectMath3' AND `science`='$subjectScience3' AND `ap`='$subjectAP3' AND `esp`='$subjectEsp3' AND `tle`='$subjectTle3' AND `music`='$subjectMusic3' AND `art`='$subjectArts3' AND `pe`='$subjectPe3' AND `health`='$subjectHealth3' AND `student_id`='$studentInfoIdCta';");
        // $result = mysqli_query($conn, $sql); 
        // if (mysqli_num_rows($result) >0) {
        //     echo "Grades already exist";
        // } 
        // else{  
            
            // Add grade
            mysqli_query($conn, "INSERT INTO `third_grading`(`english3`, `filipino3`, `math3`, `science3`, `ap3`, `esp3`, `tle3`, `music3`, `art3`, `pe3`, `health3` , `student_id`) VALUES ('$subjectEnglish3','$subjectFilipino3','$subjectMath3','$subjectScience3','$subjectAP3','$subjectEsp3','$subjectTle3','$subjectMusic3','$subjectArts3','$subjectPe3','$subjectHealth3',$studentId3);");
        }
    // }
      //submit fourth grading grade
      if(isset($_POST['subjectEnglish4'])&& isset($_POST['studentId4']) && isset($_POST['subjectFilipino4'])&& isset($_POST['subjectMath4'])&& isset($_POST['subjectScience4'])&& isset($_POST['subjectAP4'])&& isset($_POST['subjectEsp4'])&& isset($_POST['subjectTle4'])&& isset($_POST['subjectMusic4'])&& isset($_POST['subjectArts4'])&& isset($_POST['subjectPe4'])&& isset($_POST['subjectHealth4'])){
        
        $studentId4 = mysqli_real_escape_string($conn, $_POST['studentId4']);
        $subjectEnglish4 = mysqli_real_escape_string($conn, $_POST['subjectEnglish4']);
        $subjectFilipino4 = mysqli_real_escape_string($conn, $_POST['subjectFilipino4']);
        $subjectMath4 = mysqli_real_escape_string($conn, $_POST['subjectMath4']);
        $subjectScience4 = mysqli_real_escape_string($conn, $_POST['subjectScience4']);
        $subjectAP4 = mysqli_real_escape_string($conn, $_POST['subjectAP4']);
        $subjectEsp4 = mysqli_real_escape_string($conn, $_POST['subjectEsp4']);
        $subjectTle4 = mysqli_real_escape_string($conn, $_POST['subjectTle4']);
        $subjectMusic4 = mysqli_real_escape_string($conn, $_POST['subjectMusic4']);
        $subjectArts4 = mysqli_real_escape_string($conn, $_POST['subjectArts4']);
        $subjectPe4 = mysqli_real_escape_string($conn, $_POST['subjectPe4']);
        $subjectHealth4 = mysqli_real_escape_string($conn, $_POST['subjectHealth4']);
    
        // Check if student grades already exist
        // $sql = mysqli_query($conn, "SELECT * FROM `first_grading` WHERE `english`='$subjectEnglish4' AND `filipino`='$subjectFilipino4' AND `math`='$subjectMath4' AND `science`='$subjectScience4' AND `ap`='$subjectAP4' AND `esp`='$subjectEsp4' AND `tle`='$subjectTle4' AND `music`='$subjectMusic4' AND `art`='$subjectArts4' AND `pe`='$subjectPe4' AND `health`='$subjectHealth4' AND `student_id`='$studentInfoIdCta';");
        // $result = mysqli_query($conn, $sql); 
        // if (mysqli_num_rows($result) >0) {
        //     echo "Grades already exist";
        // } 
        // else{  
            
            // Add grade
            mysqli_query($conn, "INSERT INTO `fourth_grading`(`english4`, `filipino4`, `math4`, `science4`, `ap4`, `esp4`, `tle4`, `music4`, `art4`, `pe4`, `health4`, `student_id`) VALUES ('$subjectEnglish4','$subjectFilipino4','$subjectMath4','$subjectScience4','$subjectAP4','$subjectEsp4','$subjectTle4','$subjectMusic4','$subjectArts4','$subjectPe4','$subjectHealth4',$studentId4);");
        }
    // }
    //submit update grade
    // if(isset($_GET['updateGrade']) && isset($_GET['entriesName']) && isset($_GET['subjectEnglish']) && isset($_GET['updateMiddleName'])&& isset($_POST['subjectFilipino'])&& isset($_POST['subjectMath'])&& isset($_POST['subjectScience'])&& isset($_POST['subjectAP'])&& isset($_POST['subjectEsp'])&& isset($_POST['subjectTle'])&& isset($_POST['subjectMusic'])&& isset($_POST['subjectArts'])&& isset($_POST['subjectPe'])&& isset($_POST['subjectHealth']) && isset($_GET['subjectEnglish2']) && isset($_GET['updateMiddleName2'])&& isset($_POST['subjectFilipino2'])&& isset($_POST['subjectMath2'])&& isset($_POST['subjectScience2'])&& isset($_POST['subjectAP2'])&& isset($_POST['subjectEsp2'])&& isset($_POST['subjectTle2'])&& isset($_POST['subjectMusic2'])&& isset($_POST['subjectArts2'])&& isset($_POST['subjectPe2'])&& isset($_POST['subjectHealth2'])  && isset($_GET['subjectEnglish3']) && isset($_GET['updateMiddleName3'])&& isset($_POST['subjectFilipino3'])&& isset($_POST['subjectMath3'])&& isset($_POST['subjectScience3'])&& isset($_POST['subjectAP3'])&& isset($_POST['subjectEsp3'])&& isset($_POST['subjectTle3'])&& isset($_POST['subjectMusic3'])&& isset($_POST['subjectArts3'])&& isset($_POST['subjectPe3'])&& isset($_POST['subjectHealth3'])  && isset($_GET['subjectEnglish4']) && isset($_GET['updateMiddleName4'])&& isset($_POST['subjectFilipino4'])&& isset($_POST['subjectMath4'])&& isset($_POST['subjectScience4'])&& isset($_POST['subjectAP4'])&& isset($_POST['subjectEsp4'])&& isset($_POST['subjectTle4'])&& isset($_POST['subjectMusic4'])&& isset($_POST['subjectArts4'])&& isset($_POST['subjectPe4'])&& isset($_POST['subjectHealth4'])){
    //     $studentId =  $_SESSION['updateStudentGrades'];
    //     $entriesName = $_GET['entriesName'];
    //     $subjectEnglish = mysqli_real_escape_string($conn, $_POST['subjectEnglish']);
    //     $subjectFilipino = mysqli_real_escape_string($conn, $_POST['subjectFilipino']);
    //     $subjectMath = mysqli_real_escape_string($conn, $_POST['subjectMath']);
    //     $subjectScience = mysqli_real_escape_string($conn, $_POST['subjectScience']);
    //     $subjectAP = mysqli_real_escape_string($conn, $_POST['subjectAP']);
    //     $subjectEsp = mysqli_real_escape_string($conn, $_POST['subjectEsp']);
    //     $subjectTle = mysqli_real_escape_string($conn, $_POST['subjectTle']);
    //     $subjectMusic = mysqli_real_escape_string($conn, $_POST['subjectMusic']);
    //     $subjectArts = mysqli_real_escape_string($conn, $_POST['subjectArts']);
    //     $subjectPe = mysqli_real_escape_string($conn, $_POST['subjectPe']);
    //     $subjectHealth = mysqli_real_escape_string($conn, $_POST['subjectHealth']);
    //     $subjectEnglish2 = mysqli_real_escape_string($conn, $_POST['subjectEnglish2']);
    //     $subjectFilipino2 = mysqli_real_escape_string($conn, $_POST['subjectFilipino2']);
    //     $subjectMath2 = mysqli_real_escape_string($conn, $_POST['subjectMath2']);
    //     $subjectScience2 = mysqli_real_escape_string($conn, $_POST['subjectScience2']);
    //     $subjectAP2 = mysqli_real_escape_string($conn, $_POST['subjectAP']);
    //     $subjectEsp2 = mysqli_real_escape_string($conn, $_POST['subjectEsp2']);
    //     $subjectTle2 = mysqli_real_escape_string($conn, $_POST['subjectTle2']);
    //     $subjectMusic2 = mysqli_real_escape_string($conn, $_POST['subjectMusic2']);
    //     $subjectArts2 = mysqli_real_escape_string($conn, $_POST['subjectArts2']);
    //     $subjectPe2 = mysqli_real_escape_string($conn, $_POST['subjectPe2']);
    //     $subjectHealth2 = mysqli_real_escape_string($conn, $_POST['subjectHealth2']);
    //     $subjectEnglish3 = mysqli_real_escape_string($conn, $_POST['subjectEnglish3']);
    //     $subjectFilipino3 = mysqli_real_escape_string($conn, $_POST['subjectFilipino3']);
    //     $subjectMath3 = mysqli_real_escape_string($conn, $_POST['subjectMath3']);
    //     $subjectScience3 = mysqli_real_escape_string($conn, $_POST['subjectScience3']);
    //     $subjectAP3 = mysqli_real_escape_string($conn, $_POST['subjectAP']);
    //     $subjectEsp3 = mysqli_real_escape_string($conn, $_POST['subjectEsp3']);
    //     $subjectTle3 = mysqli_real_escape_string($conn, $_POST['subjectTle3']);
    //     $subjectMusic3 = mysqli_real_escape_string($conn, $_POST['subjectMusic3']);
    //     $subjectArts3 = mysqli_real_escape_string($conn, $_POST['subjectArts3']);
    //     $subjectPe3 = mysqli_real_escape_string($conn, $_POST['subjectPe3']);
    //     $subjectHealth3 = mysqli_real_escape_string($conn, $_POST['subjectHealth3']);
    //     $subjectEnglish4 = mysqli_real_escape_string($conn, $_POST['subjectEnglish4']);
    //     $subjectFilipino4 = mysqli_real_escape_string($conn, $_POST['subjectFilipino4']);
    //     $subjectMath4 = mysqli_real_escape_string($conn, $_POST['subjectMath4']);
    //     $subjectScience4 = mysqli_real_escape_string($conn, $_POST['subjectScience4']);
    //     $subjectAP4 = mysqli_real_escape_string($conn, $_POST['subjectAP']);
    //     $subjectEsp4 = mysqli_real_escape_string($conn, $_POST['subjectEsp4']);
    //     $subjectTle4 = mysqli_real_escape_string($conn, $_POST['subjectTle4']);
    //     $subjectMusic4 = mysqli_real_escape_string($conn, $_POST['subjectMusic4']);
    //     $subjectArts4 = mysqli_real_escape_string($conn, $_POST['subjectArts4']);
    //     $subjectPe4 = mysqli_real_escape_string($conn, $_POST['subjectPe4']);
    //     $subjectHealth4 = mysqli_real_escape_string($conn, $_POST['subjectHealth4']);
    
    //     //for first grading
    //     mysqli_query($conn, "UPDATE `first_grading` SET `english`='$subjectEnglish',`filipino`='$subjectFilipino',`math`=' $subjectMath',`science`='$subjectScience',`ap`='$subjectAP',`esp`='$subjectEsp',`tle`='$subjectTle',`music`='$subjectMusic',`art`='$subjectArts',`pe`='$subjectPe',`health`='$subjectHealth' WHERE `student_id`=$studentId;");

    //     //for second grading
    //     mysqli_query($conn, "UPDATE `second_grading` SET `english2`='$subjectEnglish2',`filipino2`='$subjectFilipino2',`math2`=' $subjectMath2',`science2`='$subjectScience2',`ap2`='$subjectAP2',`esp2`='$subjectEsp2',`tle`='$subjectTle',`music2`='$subjectMusic2',`art2`='$subjectArts2',`pe2`='$subjectPe2',`health2`='$subjectHealth2' WHERE `student_id`=$studentId;");
    
    //     //for third grading
    //     mysqli_query($conn, "UPDATE `third_grading` SET `english3`='$subjectEnglish3',`filipino3`='$subjectFilipino3',`math3`=' $subjectMath3',`science3`='$subjectScience3',`ap3`='$subjectAP3',`esp3`='$subjectEsp3',`tle`='$subjectTle',`music3`='$subjectMusic3',`art3`='$subjectArts3',`pe3`='$subjectPe3',`health3`='$subjectHealth3' WHERE `student_id`=$studentId;");

    //     //for fourth grading
    //     mysqli_query($conn, "UPDATE `fourth_grading` SET `english4`='$subjectEnglish4',`filipino4`='$subjectFilipino4',`math4`=' $subjectMath4',`science4`='$subjectScience4',`ap4`='$subjectAP4',`esp4`='$subjectEsp4',`tle`='$subjectTle',`music4`='$subjectMusic4',`art4`='$subjectArts4',`pe4`='$subjectPe4',`health4`='$subjectHealth4' WHERE `student_id`=$studentId;");
    
    //     tableName(1,$_GET['entriesName']);        
    // }
    //update first grading
    if(isset($_GET['updateStudentGrades1'])){
        $id = $_GET['updateStudentGrades1'];
        $_SESSION['updateStudentGrades1'] =$id;
        $query = mysqli_query($conn, "SELECT * FROM `students` INNER JOIN `first_grading` ON `students`.`student_id`=`first_grading`.`student_id` WHERE `students`.`student_id`=$id;");

        if(mysqli_num_rows($query)>0){
            $rows = mysqli_fetch_assoc($query);?>

                <h4 class="title">First Grading</h4>
                <hr>
                <div class="details">
                    <section class="column">
                        <div>
                            <label for="updateSubjectEnglish">English:</label>
                            <input type="text" id="updateSubjectEnglish" value="<?php echo $rows['english']?>">
                        </div>
                        <div>
                            <label for="updateSubjectFilipino">Filipino:</label>
                            <input type="text" id="updateSubjectFilipino" value="<?php echo $rows['filipino']?>">
                        </div>
                        <div>
                            <label for="updateSubjectMath">Math:</label>
                            <input type="text" id="updateSubjectMath" value="<?php echo $rows['math']?>">
                        </div>
                        <div>
                            <label for="updateSubjectScience">Science:</label>
                            <input type="text" id="updateSubjectScience" value="<?php echo $rows['science']?>">
                        </div>
                        <div>
                            <label for="updateSubjectAP">Araling Panlipunan:</label>
                            <input type="text" id="updateSubjectAP" value="<?php echo $rows['ap']?>">
                        </div>
                    </section>
                    <section class="column">
                        <div>
                            <label for="updateSubjectEsp">Edukasyon sa Pagpapakatao:</label>
                            <input type="text" id="updateSubjectEsp" value="<?php echo $rows['esp']?>">
                        </div>
                        <div>
                            <label for="updateSubjectTle">Technology and Livelihood Education:</label>
                            <input type="text" id="updateSubjectTle" value="<?php echo $rows['tle']?>">
                        </div>
                        <div>
                            <label for="updateSubjectMusic">Music:</label>
                            <input type="text" id="updateSubjectMusic" placeholder="Music"value="<?php echo $rows['music']?>" >
                        </div>
                        <div>
                            <label for="updateSubjectArts">Arts:</label>
                            <input type="text" id="updateSubjectArts" placeholder="Arts" value="<?php echo $rows['art']?>">
                        </div>
                        <div>
                            <label for="updateSubjectArts">PE:</label>
                            <input type="text" id="updateSubjectPe" placeholder="Pe" value="<?php echo $rows['pe']?>">
                        </div>
                        <div>
                            <label for="updateSubjectArts">Health:</label>
                            <input type="text" id="updateSubjectHealth" placeholder="Health" value="<?php echo $rows['health']?>">
                        </div>
                    </section>
                </div><?php
        }

    }
    //update second grading
    if(isset($_GET['updateStudentGrades2'])){
        $gradeId2 = $_GET['updateStudentGrades2'];
        $_SESSION['updateStudentGrades2'] =$gradeId2;
        $query = mysqli_query($conn, "SELECT * FROM `students` INNER JOIN `second_grading` ON `students`.`student_id`=`second_grading`.`student_id` WHERE `students`.`student_id`=$gradeId2;");

        if(mysqli_num_rows($query)>0){
            $rows = mysqli_fetch_assoc($query);?>

                <h4 class="title">Second Grading</h4>
                <hr>
                <div class="details">
                    <section class="column">
                        <div>
                            <label for="updateSubjectEnglish">English:</label>
                            <input type="text" id="updateSubjectEnglish2" value="<?php echo $rows['english2']?>">
                        </div>
                        <div>
                            <label for="updateSubjectFilipino">Filipino:</label>
                            <input type="text" id="updateSubjectFilipino2" value="<?php echo $rows['filipino2']?>">
                        </div>
                        <div>
                            <label for="updateSubjectMath">Math:</label>
                            <input type="text" id="updateSubjectMath2" value="<?php echo $rows['math2']?>">
                        </div>
                        <div>
                            <label for="updateSubjectScience">Science:</label>
                            <input type="text" id="updateSubjectScience2" value="<?php echo $rows['science2']?>">
                        </div>
                        <div>
                            <label for="updateSubjectAP">Araling Panlipunan:</label>
                            <input type="text" id="updateSubjectAP2" value="<?php echo $rows['ap2']?>">
                        </div>
                    </section>
                    <section class="column">
                        <div>
                            <label for="updateSubjectEsp">Edukasyon sa Pagpapakatao:</label>
                            <input type="text" id="updateSubjectEsp2" value="<?php echo $rows['esp2']?>">
                        </div>
                        <div>
                            <label for="updateSubjectTle">Technology and Livelihood Education:</label>
                            <input type="text" id="updateSubjectTle2" value="<?php echo $rows['tle2']?>">
                        </div>
                        <div>
                            <label for="updateSubjectMusic">Music:</label>
                            <input type="text" id="updateSubjectMusic2" placeholder="Music"value="<?php echo $rows['music2']?>" >
                        </div>
                        <div>
                            <label for="updateSubjectArts">Arts:</label>
                            <input type="text" id="updateSubjectArts2" placeholder="Arts" value="<?php echo $rows['art2']?>">
                        </div>
                        <div>
                            <label for="updateSubjectArts">PE:</label>
                            <input type="text" id="updateSubjectPe2" placeholder="Pe" value="<?php echo $rows['pe2']?>">
                        </div>
                        <div>
                            <label for="updateSubjectArts">Health:</label>
                            <input type="text" id="updateSubjectHealth2" placeholder="Health" value="<?php echo $rows['health2']?>">
                        </div>
                    </section>
                </div><?php
        }

    }
    //update third grading
    if(isset($_GET['updateStudentGrades3'])){
        $gradeId3 = $_GET['updateStudentGrades3'];
        $_SESSION['updateStudentGrades3'] =$gradeId3;
        $query = mysqli_query($conn, "SELECT * FROM `students` INNER JOIN `third_grading` ON `students`.`student_id`=`third_grading`.`student_id` WHERE `students`.`student_id`=$gradeId3;");

        if(mysqli_num_rows($query)>0){
            $rows = mysqli_fetch_assoc($query);?>

                <h4 class="title">Third Grading</h4>
                <hr>
                <div class="details">
                    <section class="column">
                        <div>
                            <label for="updateSubjectEnglish">English:</label>
                            <input type="text" id="updateSubjectEnglish3" value="<?php echo $rows['english3']?>">
                        </div>
                        <div>
                            <label for="updateSubjectFilipino">Filipino:</label>
                            <input type="text" id="updateSubjectFilipino3" value="<?php echo $rows['filipino3']?>">
                        </div>
                        <div>
                            <label for="updateSubjectMath">Math:</label>
                            <input type="text" id="updateSubjectMath3" value="<?php echo $rows['math3']?>">
                        </div>
                        <div>
                            <label for="updateSubjectScience">Science:</label>
                            <input type="text" id="updateSubjectScience3" value="<?php echo $rows['science3']?>">
                        </div>
                        <div>
                            <label for="updateSubjectAP">Araling Panlipunan:</label>
                            <input type="text" id="updateSubjectAP3" value="<?php echo $rows['ap3']?>">
                        </div>
                    </section>
                    <section class="column">
                        <div>
                            <label for="updateSubjectEsp">Edukasyon sa Pagpapakatao:</label>
                            <input type="text" id="updateSubjectEsp3" value="<?php echo $rows['esp3']?>">
                        </div>
                        <div>
                            <label for="updateSubjectTle">Technology and Livelihood Education:</label>
                            <input type="text" id="updateSubjectTle3" value="<?php echo $rows['tle3']?>">
                        </div>
                        <div>
                            <label for="updateSubjectMusic">Music:</label>
                            <input type="text" id="updateSubjectMusic3" placeholder="Music"value="<?php echo $rows['music3']?>" >
                        </div>
                        <div>
                            <label for="updateSubjectArts">Arts:</label>
                            <input type="text" id="updateSubjectArts3" placeholder="Arts" value="<?php echo $rows['art3']?>">
                        </div>
                        <div>
                            <label for="updateSubjectArts">PE:</label>
                            <input type="text" id="updateSubjectPe3" placeholder="Pe" value="<?php echo $rows['pe3']?>">
                        </div>
                        <div>
                            <label for="updateSubjectArts">Health:</label>
                            <input type="text" id="updateSubjectHealth3" placeholder="Health" value="<?php echo $rows['health3']?>">
                        </div>
                    </section>
                </div><?php
        }

    }
    //update third grading
    if(isset($_GET['updateStudentGrades4'])){
        $gradeId4 = $_GET['updateStudentGrades4'];
        $_SESSION['updateStudentGrades4'] =$gradeId4;
        $query = mysqli_query($conn, "SELECT * FROM `students` INNER JOIN `fourth_grading` ON `students`.`student_id`=`fourth_grading`.`student_id` WHERE `students`.`student_id`=$gradeId4;");

        if(mysqli_num_rows($query)>0){
            $rows = mysqli_fetch_assoc($query);?>

                <h4 class="title">Fourth Grading</h4>
                <hr>
                <div class="details">
                    <section class="column">
                        <div>
                            <label for="updateSubjectEnglish">English:</label>
                            <input type="text" id="updateSubjectEnglish4" value="<?php echo $rows['english4']?>">
                        </div>
                        <div>
                            <label for="updateSubjectFilipino">Filipino:</label>
                            <input type="text" id="updateSubjectFilipino4" value="<?php echo $rows['filipino4']?>">
                        </div>
                        <div>
                            <label for="updateSubjectMath">Math:</label>
                            <input type="text" id="updateSubjectMath4" value="<?php echo $rows['math4']?>">
                        </div>
                        <div>
                            <label for="updateSubjectScience">Science:</label>
                            <input type="text" id="updateSubjectScience4" value="<?php echo $rows['science4']?>">
                        </div>
                        <div>
                            <label for="updateSubjectAP">Araling Panlipunan:</label>
                            <input type="text" id="updateSubjectAP4" value="<?php echo $rows['ap4']?>">
                        </div>
                    </section>
                    <section class="column">
                        <div>
                            <label for="updateSubjectEsp">Edukasyon sa Pagpapakatao:</label>
                            <input type="text" id="updateSubjectEsp4" value="<?php echo $rows['esp4']?>">
                        </div>
                        <div>
                            <label for="updateSubjectTle">Technology and Livelihood Education:</label>
                            <input type="text" id="updateSubjectTle4" value="<?php echo $rows['tle4']?>">
                        </div>
                        <div>
                            <label for="updateSubjectMusic">Music:</label>
                            <input type="text" id="updateSubjectMusic4" placeholder="Music"value="<?php echo $rows['music4']?>" >
                        </div>
                        <div>
                            <label for="updateSubjectArts">Arts:</label>
                            <input type="text" id="updateSubjectArts4" placeholder="Arts" value="<?php echo $rows['art4']?>">
                        </div>
                        <div>
                            <label for="updateSubjectArts">PE:</label>
                            <input type="text" id="updateSubjectPe4" placeholder="Pe" value="<?php echo $rows['pe4']?>">
                        </div>
                        <div>
                            <label for="updateSubjectArts">Health:</label>
                            <input type="text" id="updateSubjectHealth4" placeholder="Health" value="<?php echo $rows['health4']?>">
                        </div>
                    </section>
                </div><?php
        }

    }
    //submit update first grading
    if(isset($_GET['updateStudentGrades1'])&&isset($_GET['updateSubjectEnglish'])&& isset($_POST['updateName'])&& isset($_POST['entriesName'])&& isset($_POST['updateSubjectFilipino'])&& isset($_POST['updateSubjectMath'])&& isset($_POST['updateSubjectScience'])&& isset($_POST['updateSubjectAP'])&& isset($_POST['updateSubjectEsp'])&& isset($_POST['updateSubjectTle'])&& isset($_POST['updateSubjectMusic'])&& isset($_POST['updateSubjectArts'])&& isset($_POST['updateSubjectPe'])&& isset($_POST['updateSubjectHealth'])){
      
        $id = $_SESSION['updateStudentGrades1'];
        $entriesName = $_GET['entriesName'];
        $updateSubjectEnglish = mysqli_real_escape_string($conn, $_POST['updateSubjectEnglish']);
        $updateSubjectFilipino = mysqli_real_escape_string($conn, $_POST['updateSubjectFilipino']);
        $updateSubjectMath = mysqli_real_escape_string($conn, $_POST['updateSubjectMath']);
        $updateSubjectScience = mysqli_real_escape_string($conn, $_POST['updateSubjectScience']);
        $updateSubjectAP = mysqli_real_escape_string($conn, $_POST['updateSubjectAP']);
        $updateSubjectEsp = mysqli_real_escape_string($conn, $_POST['updateSubjectEsp']);
        $updateSubjectTle = mysqli_real_escape_string($conn, $_POST['updateSubjectTle']);
        $updateSubjectMusic = mysqli_real_escape_string($conn, $_POST['updateSubjectMusic']);
        $updateSubjectArts = mysqli_real_escape_string($conn, $_POST['updateSubjectArts']);
        $updateSubjectPe = mysqli_real_escape_string($conn, $_POST['updateSubjectPe']);
        $updateSubjectHealth = mysqli_real_escape_string($conn, $_POST['updateSubjectHealth']);
    
        //for first grading
        mysqli_query($conn, "UPDATE `first_grading` SET `english`='$updateSubjectEnglish',`filipino`='$updateSubjectFilipino',`math`=' $updateSubjectMath',`science`='$updateSubjectScience',`ap`='$updateSubjectAP',`esp`='$updateSubjectEsp',`tle`='$updateSubjectTle',`music`='$updateSubjectMusic',`art`='$updateSubjectArts',`pe`='$updateSubjectPe',`health`='$updateSubjectHealth' WHERE `first_grading_id`=$id;");   
    }
?>