//add new student
function addNewFormCta(){
    _query(".new-enrollment").showModal();
}
//add new schoolyear
function addNewSchoolYearCta(){
    _query(".new-schoolyear").showModal();
}
//close schoolyear modal
function closeNewSchoolYearCta(){
    _elementId("newSchoolYear").value = "";
    _query(".new-schoolyear").close();
}
//submit new school year
function submitNewSchoolYearCta(){
    const newSchoolYear = _elementId("newSchoolYear").value.trim();


    if(newSchoolYear === ""){
        alert("All fields are required");
    }
    else{
        const x = new XMLHttpRequest();
        x.onload = function(){
            if(this.responseText === "School year already exists"){
                alert("School year already exists");
            }
            else{
                alert("New School year added successfully");
                _elementId("newSchoolYear").value = "";
                _query(".new-schoolyear").close();
            }
        }
        x.open("POST","../registrar_re/enroll_student.php");
        x.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        x.send("newSchoolYear="+encodeURIComponent(newSchoolYear));
               
    }
}
//select for schoolyear
function schoolYearCta(){
    const userType =_elementId("schoolYear").value.trim();
    _elementId("enrollmentForm").classList.remove("display-none");
}
//submit new student
function submitNewEnrollCta(){
    const studentFirstName = _elementId("studentFirstName").value.trim();
    const studentMiddleName = _elementId("studentMiddleName").value.trim();
    const studentLastName = _elementId("studentLastName").value.trim();
    const studentSuffix = _elementId("studentSuffix").value.trim();
    const studentSex = _elementId("studentSex").value.trim();
    const studentBirthDate = _elementId("studentBirthDate").value.trim();
    const studentAge = _elementId("studentAge").value.trim();
    const studentEmailAddress = _elementId("studentEmailAddress").value.trim();
    const studentAddress = _elementId("studentAddress").value.trim();
    const studentYearLevel = _elementId("studentYearLevel").value.trim();
    const studentSection = _elementId("studentSection").value.trim();
    const studentParentGuardian = _elementId("studentParentGuardian").value.trim();
    const studentParentAddress = _elementId("studentParentAddress").value.trim();
    const studentParentOccupation = _elementId("studentParentOccupation").value.trim();
    const studentContactNumber = _elementId("studentContactNumber").value.trim();
    const studentParentContactNumber = _elementId("studentParentContactNumber").value.trim();
    const studentRelation = _elementId("studentRelation").value.trim();
    const studentSchoolYear = _elementId("studentSchoolYear").value.trim();
    const entriesName = _elementId("entriesName").value.trim();

    if(studentFirstName === "" || studentMiddleName === "" || studentLastName === "" || studentSex === "" || studentBirthDate === "" || studentAge === "" || studentEmailAddress === "" || studentAddress === "" || studentYearLevel === "" || studentSection === "" || studentParentGuardian === ""|| studentParentAddress === ""|| studentParentOccupation === ""|| studentContactNumber === ""|| studentParentContactNumber === ""|| studentRelation === ""|| studentSchoolYear === ""){
        alert("All fields are required");
    }
    else{
        const x = new XMLHttpRequest();
        x.onload = function(){
            if(this.responseText === "Name already exists"){
                alert("Name already exists");
            }
            else{
                alert("New enrolled student added successfully");
                _elementId("studentFirstName").value = "";
                _elementId("studentMiddleName").value = "";
                _elementId("studentLastName").value = "";
                _elementId("studentSuffix").value = "";
                _elementId("studentSex").value = "";
                _elementId("studentAge").value = "";
                _elementId("studentBirthDate").value = "";
                _elementId("studentEmailAddress").value = "";
                _elementId("studentAddress").value = "";
                _elementId("studentYearLevel").value = "";
                _elementId("studentSection").value = "";
                _elementId("studentParentGuardian").value = "";
                _elementId("studentParentOccupation").value = "";
                _elementId("studentContactNumber").value = "";
                _elementId("studentParentAddress").value = "";
                _elementId("studentParentContactNumber").value = "";
                _elementId("studentRelation").value = "";
                _elementId("studentSchoolYear").value = "";
                _query(".new-enrollment").close();
                _query("[tableName]").innerHTML = this.responseText;
            }
        }
        x.open("POST","../registrar_re/enroll_student.php");
        x.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        x.send("studentFirstName="+encodeURIComponent(studentFirstName)+"&studentMiddleName="+encodeURIComponent(studentMiddleName)+"&studentLastName="+encodeURIComponent(studentLastName)+"&studentSuffix="+encodeURIComponent(studentSuffix)+"&studentSex="+encodeURIComponent(studentSex)+"&studentBirthDate="+encodeURIComponent(studentBirthDate)+"&studentAge="+encodeURIComponent(studentAge)+"&studentEmailAddress="+encodeURIComponent(studentEmailAddress)+"&studentAddress="+encodeURIComponent(studentAddress)+"&studentYearLevel="+encodeURIComponent(studentYearLevel)+"&studentSection="+encodeURIComponent(studentSection)+"&studentParentGuardian="+encodeURIComponent(studentParentGuardian)+"&studentParentOccupation="+encodeURIComponent(studentParentOccupation)+"&studentParentAddress="+encodeURIComponent(studentParentAddress)+"&studentContactNumber="+encodeURIComponent(studentContactNumber)+"&studentParentContactNumber="+encodeURIComponent(studentParentContactNumber)+"&studentRelation="+encodeURIComponent(studentRelation)+"&studentSchoolYear="+encodeURIComponent(studentSchoolYear)+"&entriesName="+encodeURIComponent(entriesName));
               
    }
}
//search student name
function searchStudentCta(){
    const filterName = _elementId("filterName").value.trim();
    const searchName = _elementId("searchName").value.trim();
    const entriesName = _elementId("entriesName").value.trim();

    const x = new XMLHttpRequest();
    x.onload = function(){
        _query("[tableName]").innerHTML = this.responseText;
    }
    x.open("GET","../registrar_re/enroll_student.php?filterName="+encodeURIComponent(filterName)+"&searchName="+encodeURIComponent(searchName)+"&entriesName="+encodeURIComponent(entriesName));
    x.send();
}
//search student for grade
function searchStudentGradeCta(){
    const filterName = _elementId("filterName").value.trim();
    const searchName = _elementId("searchName").value.trim();
    const entriesName = _elementId("entriesName").value.trim();

    const x = new XMLHttpRequest();
    x.onload = function(){
        _query("[tableName]").innerHTML = this.responseText;
    }
    x.open("GET","../registrar_re/encode_grades.php?filterName="+encodeURIComponent(filterName)+"&searchName="+encodeURIComponent(searchName)+"&entriesName="+encodeURIComponent(entriesName));
    x.send();
}

//previous page account
function prevPageNameCta(prevPage){
    const entriesName = _elementId("entriesName").value.trim();
    const x = new XMLHttpRequest();
    x.onload = function(){
        _query("[tableName]").innerHTML = this.responseText;
    }
    x.open("GET","../registar_re/enroll_student.php?prevPage="+encodeURIComponent(prevPage)+"&entriesName="+encodeURIComponent(entriesName));
    x.send();
}

//next page account
function nextPageNameCta(nextPage){
    const entriesName = _elementId("entriesName").value.trim();
    const x = new XMLHttpRequest();
    x.onload = function(){
        _query("[tableName]").innerHTML = this.responseText;
    }
    x.open("GET","../registar_re/enroll_student.php?nextPage="+encodeURIComponent(nextPage)+"&entriesName="+encodeURIComponent(entriesName));
    x.send();
}

//entries name
function entriesNameCta(){
    const entriesName = _elementId("entriesName").value.trim();
    const x = new XMLHttpRequest();
    x.onload = function(){
        _query("[tableName]").innerHTML = this.responseText;
    }
    x.open("GET","../registrar_re/enroll_student.php?entriesName="+encodeURIComponent(entriesName)+"&showPerPage");
    x.send();
}

//close schoolyear
function closeEnrollmentFormCta(){
    _elementId("schoolYear").value = "";
    _query(".new-enrollment").close();
}
//close enrollmentform
function closeEnrollmentFormCta(){
    _elementId("studentFirstName").value = "";
    _elementId("studentMiddleName").value = "";
    _elementId("studentLastName").value = "";
    _elementId("studentSuffix").value = "";
    _elementId("studentBirthDate").value = "";
    _elementId("studentSex").value = "";
    _elementId("studentAddress").value = "";
    _elementId("studentEmailAddress").value = "";
    _elementId("studentContactNumber").value = "";
    _elementId("studentYearLevel").value = "";
    _elementId("studentSection").value = "";
    _elementId("studentParentGuardian").value = "";
    _elementId("studentParentAddress").value = "";
    _elementId("studentParentOccupation").value = "";
    _elementId("studentParentContactNumber").value = "";
    _elementId("studentRelation").value = "";
    _query(".new-enrollment").close();  
}
// edit info
function editStudentInfoCta(id){
    const x = new XMLHttpRequest();
    x.onload = function(){
        _elementId("updateStudents").innerHTML = this.responseText;
        _query(".update-enrollment").showModal();
    }
    x.open("GET","../registrar_re/enroll_student.php?editStudentInfo="+encodeURIComponent(id));
    x.send();

}
//view info
function viewStudentInfoCta(id){
    const x = new XMLHttpRequest();
    x.onload = function(){
        _elementId("updateStudents").innerHTML = this.responseText;
        _query(".update-enrollment").showModal();
    }
    x.open("GET","../registrar_re/enroll_student.php?viewStudentInfo="+encodeURIComponent(id));
    x.send();

}
//update student info
function submitNewUpdateEnrollCta(){
    const entriesName = _elementId("entriesName").value.trim();
    const updateFirstName = _elementId("updateFirstName").value.trim();
    const updateMiddleName = _elementId("updateMiddleName").value.trim();
    const updateLastName = _elementId("updateLastName").value.trim();
    const updateSuffix = _elementId("updateSuffix").value.trim();
    const updateBirthDate = _elementId("updateBirthDate").value.trim();
    const updateAge = _elementId("updateAge").value.trim();
    const updateSex = _elementId("updateSex").value.trim();
    const updateAddress = _elementId("updateAddress").value.trim();
    const updateEmailAddress = _elementId("updateEmailAddress").value.trim();
    const updateContactNumber = _elementId("updateContactNumber").value.trim();
    const updateYearLevel = _elementId("updateYearLevel").value.trim();
    const updateSection = _elementId("updateSection").value.trim();
    const updateParentGuardian = _elementId("updateParentGuardian").value.trim();
    const updateParentAddress = _elementId("updateParentAddress").value.trim();
    const updateParentOccupation = _elementId("updateParentOccupation").value.trim();
    const updateParentContactNumber = _elementId("updateParentContactNumber").value.trim();
    const updateRelation = _elementId("updateRelation").value.trim();
    const x = new XMLHttpRequest();
    x.onload = function(){
        _query("[tableName]").innerHTML = this.responseText;
        _query(".update-enrollment").close();
    }
    x.open("GET","../registrar_re/enroll_student.php?updateName&entriesName="+entriesName+"&updateFirstName="+updateFirstName+"&updateMiddleName="+updateMiddleName+"&updateLastName="+updateLastName+"&updateSuffix="+updateSuffix+"&updateBirthDate="+updateBirthDate+"&updateAge="+updateAge+"&updateSex="+updateSex+"&updateAddress="+updateAddress+"&updateEmailAddress="+updateEmailAddress+"&updateContactNumber="+updateContactNumber+"&updateYearLevel="+updateYearLevel+"&updateSection="+updateSection+"&updateParentGuardian="+updateParentGuardian+"&updateParentAddress="+updateParentAddress+"&updateParentOccupation="+updateParentOccupation+"&updateParentContactNumber="+updateParentContactNumber+"&updateRelation="+updateRelation);
    x.send();
}
//close update
function closeUpdateInfoCta(){
    _query(".update-enrollment").close();
}

//add new subjects
function addNewSubjectCta(){
    _query(".new-subject").showModal();
}
//close subject modal
function closeSubjectCta(){
    _elementId("newSubject").value = "";
    _query(".new-subject").close();
}
//submit new subjects
function submitnewSubjectCta(){
    const newSubject = _elementId("newSubject").value.trim();


    if(newSubject === ""){
        alert("All fields are required");
    }
    else{
        const x = new XMLHttpRequest();
        x.onload = function(){
            if(this.responseText === "Subjects already exists"){
                alert("Subjects already exists");
            }
            else{
                alert("New Subjects added successfully");
                _elementId("newSubject").value = "";
            }
        }
        x.open("POST","../registrar_re/encode_grades.php");
        x.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        x.send("newSubject="+encodeURIComponent(newSubject));
               
    }
}
//add new grades
function addStudentsGradeCta(){
    _query(".new-subject").showModal();
}
//add select grading
function addStudentsGradeCta(){
    _query(".add-grade").showModal();
}
//close selection for grading
function closeGradeCta(){
    _elementId("gradingPeriod").value = "";
    _query(".add-grade").close();
}
//choose grading
function gradingPeriodCta(){
    const gradingPeriod =_elementId("gradingPeriod").value.trim();
    if(gradingPeriod === "firstgrading"){
        _elementId("studentInfoForFirstGrading").classList.remove("display-none");
        _elementId("studentInfoForSecondGrading").classList.add("display-none");
        _elementId("studentInfoForThirdGrading").classList.add("display-none");
        _elementId("studentInfoForFourthGrading").classList.add("display-none");
    }
     else if(gradingPeriod ==="secondgrading"){
         _elementId("studentInfoForFirstGrading").classList.add("display-none");
         _elementId("studentInfoForSecondGrading").classList.remove("display-none");
         _elementId("studentInfoForThirdGrading").classList.add("display-none");
         _elementId("studentInfoForFourthGrading").classList.add("display-none");
     }
     else if(gradingPeriod ==="thirdgrading"){
        _elementId("studentInfoForFirstGrading").classList.add("display-none");
         _elementId("studentInfoForSecondGrading").classList.add("display-none");
         _elementId("studentInfoForThirdGrading").classList.remove("display-none");
         _elementId("studentInfoForFourthGrading").classList.add("display-none");
     }
     else if(gradingPeriod ==="fourthgrading"){
        _elementId("studentInfoForFirstGrading").classList.add("display-none");
         _elementId("studentInfoForSecondGrading").classList.add("display-none");
         _elementId("studentInfoForThirdGrading").classList.add("display-none");
         _elementId("studentInfoForFourthGrading").classList.remove("display-none");
     }
    else{
        _elementId("studentInfoForFirstGrading").classList.add("display-none");
        _elementId("studentInfoForSecondGrading").classList.add("display-none");
        _elementId("studentInfoForThirdGrading").classList.add("display-none");
        _elementId("studentInfoForFourthGrading").classList.add("display-none");
    }
}
 //searh for student name
// function searchStudentForGradeCta(){
//     _elementId("searchStudentName").value = "";
//     _elementId("searchStudentResult").value = "";
//     _query(".add-grade").close();
// }
// // search for firstgrading option
// function searchStudentForGradeCta(){
//     const searchStudentName = _elementId("searchStudentName").value.trim();
//     const x = new XMLHttpRequest();
//     x.onload = function(){
//         _elementId("searchStudentResult").innerHTML = this.responseText;
//     }
//     x.open("GET","../registrar_re/encode_grades.php?searchStudentName="+encodeURIComponent(searchStudentName));
//     x.send();
// }
// function studentInfoIdCta(studentId){
//     const x = new XMLHttpRequest();
//     x.onload = function(){
//         _elementId("studentInfoForFirstGrading").innerHTML = this.responseText;
//     }
//     x.open("GET","../registrar_re/encode_grades.php?studentId="+encodeURIComponent(studentId));
//     x.send();
//     _elementId("studentInfoForFirstGrading").classList.remove("display-none");
//     _elementId("studentInfoForSecondGrading").classList.add("display-none");
//     _elementId("studentInfoForThirdGrading").classList.add("display-none");
//     _elementId("studentInfoForFourthGrading").classList.add("display-none");
//     _elementId("studentResult").classList.add("display-none");

// }
//  // search for secondgrading option
//  function searchStudentForGrade2Cta(){
//      const searchStudentName2 = _elementId("searchStudentName2").value.trim();
//      const x = new XMLHttpRequest();
//      x.onload = function(){
//          _elementId("searchStudentResult2").innerHTML = this.responseText;
//      }
//      x.open("GET","../registrar_re/encode_grades.php?searchStudentName2="+encodeURIComponent(searchStudentName2));
//      x.send();
//  }
//  function studentInfoId2Cta(studentId2){
//      const x = new XMLHttpRequest();
//      x.onload = function(){
//          _elementId("studentInfoForSecondGrading").innerHTML = this.responseText;
//      }
//      x.open("GET","../registrar_re/encode_grades.php?studentId2="+encodeURIComponent(studentId2));
//      x.send();
//      _elementId("studentInfoForFirstGrading").classList.add("display-none");
//      _elementId("studentInfoForSecondGrading").classList.remove("display-none");
//      _elementId("studentInfoForThirdGrading").classList.add("display-none");
//      _elementId("studentInfoForFourthGrading").classList.add("display-none");
//      _elementId("studentResult2").classList.add("display-none");

//  }
//  // search for thirdgrading option
//  function searchStudentForGrade3Cta(){
//      const searchStudentName3 = _elementId("searchStudentName3").value.trim();
//      const x = new XMLHttpRequest();
//      x.onload = function(){
//          _elementId("searchStudentResult3").innerHTML = this.responseText;
//      }
//      x.open("GET","../registrar_re/encode_grades.php?searchStudentName3="+encodeURIComponent(searchStudentName3));
//      x.send();
//  }
//  function studentInfoId3Cta(studentId3){
//      const x = new XMLHttpRequest();
//      x.onload = function(){
//          _elementId("studentInfoForSecondGrading").innerHTML = this.responseText;
//      }
//      x.open("GET","../registrar_re/encode_grades.php?studentId3="+encodeURIComponent(studentId3));
//      x.send();
//      _elementId("studentInfoForFirstGrading").classList.add("display-none");
//      _elementId("studentInfoForSecondGrading").classList.add("display-none");
//      _elementId("studentInfoForThirdGrading").classList.remove("display-none");
//      _elementId("studentInfoForFourthGrading").classList.add("display-none");
//      _elementId("studentResult3").classList.add("display-none");

//  }
//  // search for fourthgrading option
//  function searchStudentForGrade4Cta(){
//      const searchStudentName4 = _elementId("searchStudentName4").value.trim();
//      const x = new XMLHttpRequest();
//      x.onload = function(){
//          _elementId("searchStudentResult4").innerHTML = this.responseText;
//      }
//      x.open("GET","../registrar_re/encode_grades.php?searchStudentName4="+encodeURIComponent(searchStudentName4));
//      x.send();
//  }
//  function studentInfoId4Cta(studentId4){
//      const x = new XMLHttpRequest();
//      x.onload = function(){
//          _elementId("studentInfoForSecondGrading").innerHTML = this.responseText;
//      }
//      x.open("GET","../registrar_re/encode_grades.php?studentId4="+encodeURIComponent(studentId4));
//      x.send();
//      _elementId("studentInfoForFirstGrading").classList.add("display-none");
//      _elementId("studentInfoForSecondGrading").classList.add("display-none");
//      _elementId("studentInfoForThirdGrading").classList.add("display-none");
//      _elementId("studentInfoForFourthGrading").classList.remove("display-none");
//      _elementId("studentResult4").classList.add("display-none");

//  }
 //add first grading
// // function submitFirstgradingCta(){
// //     const subjectEnglish = _elementId("subjectEnglish").value.trim();
// //     const subjectFilipino = _elementId("subjectFilipino").value.trim();
// //     const subjectMath = _elementId("subjectMath").value.trim();
// //     const subjectScience = _elementId("subjectScience").value.trim();
// //     const subjectAP = _elementId("subjectAP").value.trim();
// //     const subjectEsp = _elementId("subjectEsp").value.trim();
// //     const subjectTle = _elementId("subjectTle").value.trim();
// //     const subjectMusic = _elementId("subjectMusic").value.trim();
// //     const subjectArts = _elementId("subjectArts").value.trim();
// //     const subjectPe = _elementId("subjectPe").value.trim();
// //     const subjectHealth = _elementId("subjectHealth").value.trim();
// //     const x = new XMLHttpRequest();

// //         x.onload = function(){
// //             if(this.responseText === "grade already exist"){
// //                 alert("Grades already exists");
// //             }
// //             else{
// //                 alert("New grades added successfully");
// //                 _elementId("subjectEnglish").value = "";
// //                 _elementId("subjectFilipino").value = "";
// //                 _elementId("subjectMath").value = "";
// //                 _elementId("subjectScience").value = "";
// //                 _elementId("subjectAP").value = "";
// //                 _elementId("subjectEsp").value = "";
// //                 _elementId("subjectTle").value = "";
// //                 _elementId("subjectMusic").value = "";
// //                 _elementId("subjectArts").value = "";
// //                 _elementId("subjectPe").value = "";
// //                 _elementId("subjectHealth").value = "";
// //                 _query(".add-grade").close();
// //             }
// //         }
// //         x.open("POST","../registrar_re/encode_grades.php");
// //         x.setRequestHeader("Content-type","application/x-www-form-urlencoded");
// //         x.send("subjectEnglish="+encodeURIComponent(subjectEnglish)+"&subjectFilipino="+encodeURIComponent(subjectFilipino)+"&subjectMath="+encodeURIComponent(subjectMath)+"&subjectScience="+encodeURIComponent(subjectScience)+"&subjectAP="+encodeURIComponent(subjectAP)+"&subjectEsp="+encodeURIComponent(subjectEsp)+"&subjectTle="+encodeURIComponent(subjectTle)+"&subjectMusic="+encodeURIComponent(subjectMusic)+"&subjectArts="+encodeURIComponent(subjectArts)+"&subjectPe="+encodeURIComponent(subjectPe)+"&subjectHealth="+encodeURIComponent(subjectHealth));
// // }
function submitFirstgradingCta(){
    const studentId = _elementId("studentId").value.trim();
    const subjectEnglish = _elementId("subjectEnglish").value.trim();
    const subjectFilipino = _elementId("subjectFilipino").value.trim();
    const subjectMath = _elementId("subjectMath").value.trim();
    const subjectScience = _elementId("subjectScience").value.trim();
    const subjectAP = _elementId("subjectAP").value.trim();
    const subjectEsp = _elementId("subjectEsp").value.trim();
    const subjectTle = _elementId("subjectTle").value.trim();
    const subjectMusic = _elementId("subjectMusic").value.trim();
    const subjectArts = _elementId("subjectArts").value.trim();
    const subjectPe = _elementId("subjectPe").value.trim();
    const subjectHealth = _elementId("subjectHealth").value.trim();
    const x = new XMLHttpRequest();

    if(subjectEnglish === "" || subjectFilipino === "" || subjectMath === "" || subjectScience === "" || subjectAP === "" || subjectEsp === "" || subjectTle === "" || subjectMusic === "" || subjectArts === "" || subjectPe === "" || subjectHealth === ""){
        alert("All fields are required");
    }
    else{
            const x = new XMLHttpRequest();
            x.onload = function(){
                if(this.responseText === "grade already exist"){
                    alert("Grades already exists");
                }
                else{
                    alert("New grades added successfully");
                    _elementId("subjectEnglish").value = "";
                    _elementId("subjectFilipino").value = "";
                    _elementId("subjectMath").value = "";
                    _elementId("subjectScience").value = "";
                    _elementId("subjectAP").value = "";
                    _elementId("subjectEsp").value = "";
                    _elementId("subjectTle").value = "";
                    _elementId("subjectMusic").value = "";
                    _elementId("subjectArts").value = "";
                    _elementId("subjectPe").value = "";
                    _elementId("subjectHealth").value = "";
                    _query(".add-grade").close();
                }
            }
            x.open("POST","../registrar_re/encode_grades.php");
            x.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            x.send("subjectEnglish="+encodeURIComponent(subjectEnglish)+"&studentId="+encodeURIComponent(studentId)+"&subjectFilipino="+encodeURIComponent(subjectFilipino)+"&subjectMath="+encodeURIComponent(subjectMath)+"&subjectScience="+encodeURIComponent(subjectScience)+"&subjectAP="+encodeURIComponent(subjectAP)+"&subjectEsp="+encodeURIComponent(subjectEsp)+"&subjectTle="+encodeURIComponent(subjectTle)+"&subjectMusic="+encodeURIComponent(subjectMusic)+"&subjectArts="+encodeURIComponent(subjectArts)+"&subjectPe="+encodeURIComponent(subjectPe)+"&subjectHealth="+encodeURIComponent(subjectHealth));
    }
}
//second grading
function submitSecondgradingCta(){
    const studentId2 = _elementId("studentId2").value.trim();
    const subjectEnglish2 = _elementId("subjectEnglish2").value.trim();
    const subjectFilipino2 = _elementId("subjectFilipino2").value.trim();
    const subjectMath2 = _elementId("subjectMath2").value.trim();
    const subjectScience2 = _elementId("subjectScience2").value.trim();
    const subjectAP2 = _elementId("subjectAP2").value.trim();
    const subjectEsp2 = _elementId("subjectEsp2").value.trim();
    const subjectTle2 = _elementId("subjectTle2").value.trim();
    const subjectMusic2 = _elementId("subjectMusic2").value.trim();
    const subjectArts2 = _elementId("subjectArts2").value.trim();
    const subjectPe2 = _elementId("subjectPe2").value.trim();
    const subjectHealth2 = _elementId("subjectHealth2").value.trim();
    const x = new XMLHttpRequest();

    if(subjectEnglish2 === "" || subjectFilipino2 === "" || subjectMath2 === "" || subjectScience2 === "" || subjectAP2 === "" || subjectEsp2 === "" || subjectTle2 === "" || subjectMusic2 === "" || subjectArts2 === "" || subjectPe2 === "" || subjectHealth2 === ""){
        alert("All fields are required");
    }
    else{
            const x = new XMLHttpRequest();
            x.onload = function(){
                if(this.responseText === "grade already exist"){
                    alert("Grades already exists");
                }
                else{
                    alert("New grades added successfully");
                    _elementId("subjectEnglish2").value = "";
                    _elementId("subjectFilipino2").value = "";
                    _elementId("subjectMath2").value = "";
                    _elementId("subjectScience2").value = "";
                    _elementId("subjectAP2").value = "";
                    _elementId("subjectEsp2").value = "";
                    _elementId("subjectTle2").value = "";
                    _elementId("subjectMusic2").value = "";
                    _elementId("subjectArts2").value = "";
                    _elementId("subjectPe2").value = "";
                    _elementId("subjectHealth2").value = "";
                    _query(".add-grade").close();
                }
            }
            x.open("POST","../registrar_re/encode_grades.php");
            x.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            x.send("subjectEnglish2="+encodeURIComponent(subjectEnglish2)+"&studentId2="+encodeURIComponent(studentId2)+"&subjectFilipino2="+encodeURIComponent(subjectFilipino2)+"&subjectMath2="+encodeURIComponent(subjectMath2)+"&subjectScience2="+encodeURIComponent(subjectScience2)+"&subjectAP2="+encodeURIComponent(subjectAP2)+"&subjectEsp2="+encodeURIComponent(subjectEsp2)+"&subjectTle2="+encodeURIComponent(subjectTle2)+"&subjectMusic2="+encodeURIComponent(subjectMusic2)+"&subjectArts2="+encodeURIComponent(subjectArts2)+"&subjectPe2="+encodeURIComponent(subjectPe2)+"&subjectHealth2="+encodeURIComponent(subjectHealth2));
    }
}
//third grading
function submitThirdgradingCta(){
    const studentId3 = _elementId("studentId3").value.trim();
    const subjectEnglish3 = _elementId("subjectEnglish3").value.trim();
    const subjectFilipino3 = _elementId("subjectFilipino3").value.trim();
    const subjectMath3 = _elementId("subjectMath3").value.trim();
    const subjectScience3 = _elementId("subjectScience3").value.trim();
    const subjectAP3 = _elementId("subjectAP3").value.trim();
    const subjectEsp3 = _elementId("subjectEsp3").value.trim();
    const subjectTle3 = _elementId("subjectTle3").value.trim();
    const subjectMusic3 = _elementId("subjectMusic3").value.trim();
    const subjectArts3 = _elementId("subjectArts3").value.trim();
    const subjectPe3 = _elementId("subjectPe3").value.trim();
    const subjectHealth3 = _elementId("subjectHealth3").value.trim();
    const x = new XMLHttpRequest();

    if(subjectEnglish3 === "" || subjectFilipino3 === "" || subjectMath3 === "" || subjectScience3 === "" || subjectAP3 === "" || subjectEsp3 === "" || subjectTle3 === "" || subjectMusic3 === "" || subjectArts3 === "" || subjectPe3 === "" || subjectHealth3 === ""){
        alert("All fields are required");
    }
    else{
            const x = new XMLHttpRequest();
            x.onload = function(){
                if(this.responseText === "grade already exist"){
                    alert("Grades already exists");
                }
                else{
                    alert("New grades added successfully");
                    _elementId("subjectEnglish3").value = "";
                    _elementId("subjectFilipino3").value = "";
                    _elementId("subjectMath3").value = "";
                    _elementId("subjectScience3").value = "";
                    _elementId("subjectAP3").value = "";
                    _elementId("subjectEsp3").value = "";
                    _elementId("subjectTle3").value = "";
                    _elementId("subjectMusic3").value = "";
                    _elementId("subjectArts3").value = "";
                    _elementId("subjectPe3").value = "";
                    _elementId("subjectHealth3").value = "";
                    _query(".add-grade").close();
                }
            }
            x.open("POST","../registrar_re/encode_grades.php");
            x.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            x.send("subjectEnglish3="+encodeURIComponent(subjectEnglish3)+"&studentId3="+encodeURIComponent(studentId3)+"&subjectFilipino3="+encodeURIComponent(subjectFilipino3)+"&subjectMath3="+encodeURIComponent(subjectMath3)+"&subjectScience3="+encodeURIComponent(subjectScience3)+"&subjectAP3="+encodeURIComponent(subjectAP3)+"&subjectEsp3="+encodeURIComponent(subjectEsp3)+"&subjectTle3="+encodeURIComponent(subjectTle3)+"&subjectMusic3="+encodeURIComponent(subjectMusic3)+"&subjectArts3="+encodeURIComponent(subjectArts3)+"&subjectPe3="+encodeURIComponent(subjectPe3)+"&subjectHealth3="+encodeURIComponent(subjectHealth3));
    }
}
//fouth grading
function submitFourthgradingCta(){
    const studentId4 = _elementId("studentId4").value.trim();
    const subjectEnglish4 = _elementId("subjectEnglish4").value.trim();
    const subjectFilipino4 = _elementId("subjectFilipino4").value.trim();
    const subjectMath4 = _elementId("subjectMath4").value.trim();
    const subjectScience4 = _elementId("subjectScience4").value.trim();
    const subjectAP4 = _elementId("subjectAP4").value.trim();
    const subjectEsp4 = _elementId("subjectEsp4").value.trim();
    const subjectTle4 = _elementId("subjectTle4").value.trim();
    const subjectMusic4 = _elementId("subjectMusic4").value.trim();
    const subjectArts4 = _elementId("subjectArts4").value.trim();
    const subjectPe4 = _elementId("subjectPe4").value.trim();
    const subjectHealth4 = _elementId("subjectHealth4").value.trim();
    const x = new XMLHttpRequest();

    if(subjectEnglish4 === "" || subjectFilipino4 === "" || subjectMath4 === "" || subjectScience4 === "" || subjectAP4 === "" || subjectEsp4 === "" || subjectTle4 === "" || subjectMusic4 === "" || subjectArts4 === "" || subjectPe4 === "" || subjectHealth4 === ""){
        alert("All fields are required");
    }
    else{
            const x = new XMLHttpRequest();
            x.onload = function(){
                if(this.responseText === "grade already exist"){
                    alert("Grades already exists");
                }
                else{
                    alert("New grades added successfully");
                    _elementId("subjectEnglish4").value = "";
                    _elementId("subjectFilipino4").value = "";
                    _elementId("subjectMath4").value = "";
                    _elementId("subjectScience4").value = "";
                    _elementId("subjectAP4").value = "";
                    _elementId("subjectEsp4").value = "";
                    _elementId("subjectTle4").value = "";
                    _elementId("subjectMusic4").value = "";
                    _elementId("subjectArts4").value = "";
                    _elementId("subjectPe4").value = "";
                    _elementId("subjectHealth4").value = "";
                    _query(".add-grade").close();
                }
            }
            x.open("POST","../registrar_re/encode_grades.php");
            x.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            x.send("subjectEnglish4="+encodeURIComponent(subjectEnglish4)+"&studentId4="+encodeURIComponent(studentId4)+"&subjectFilipino4="+encodeURIComponent(subjectFilipino4)+"&subjectMath4="+encodeURIComponent(subjectMath4)+"&subjectScience4="+encodeURIComponent(subjectScience4)+"&subjectAP4="+encodeURIComponent(subjectAP4)+"&subjectEsp4="+encodeURIComponent(subjectEsp4)+"&subjectTle4="+encodeURIComponent(subjectTle4)+"&subjectMusic4="+encodeURIComponent(subjectMusic4)+"&subjectArts4="+encodeURIComponent(subjectArts4)+"&subjectPe4="+encodeURIComponent(subjectPe4)+"&subjectHealth4="+encodeURIComponent(subjectHealth4));
    }
}
//update first grading
function updateStudentGrades1Cta(gradeId){
    const x = new XMLHttpRequest();
    x.onload = function(){
        _elementId("updateGrade").innerHTML = this.responseText;
        _query(".update-grade").showModal();
    }
    x.open("GET","../registrar_re/encode_grades.php?updateStudentGrades1="+encodeURIComponent(gradeId));
    x.send();

}
//update second grading
function updateStudentGrades2Cta(id){
    const x = new XMLHttpRequest();
    x.onload = function(){
        _elementId("updateGrade").innerHTML = this.responseText;
        _query(".update-grade").showModal();
    }
    x.open("GET","../registrar_re/encode_grades.php?updateStudentGrades2="+encodeURIComponent(id));
    x.send();

}
//update third Grading
function updateStudentGrades3Cta(id){
    const x = new XMLHttpRequest();
    x.onload = function(){
        _elementId("updateGrade").innerHTML = this.responseText;
        _query(".update-grade").showModal();
    }
    x.open("GET","../registrar_re/encode_grades.php?updateStudentGrades3="+encodeURIComponent(id));
    x.send();

}
//update fourth Grading
function updateStudentGrades4Cta(id){
    const x = new XMLHttpRequest();
    x.onload = function(){
        _elementId("updateGrade").innerHTML = this.responseText;
        _query(".update-grade").showModal();
    }
    x.open("GET","../registrar_re/encode_grades.php?updateStudentGrades4="+encodeURIComponent(id));
    x.send();

}
//close update
function closeUpdateGradeCta(){
    _query(".update-grade").close();
}
// //update grades
// function submitNewUpdateGradeCta(){
//     const entriesName = _elementId("entriesName").value.trim();
//     const subjectEnglish = _elementId("subjectEnglish").value.trim();
//     const subjectFilipino = _elementId("subjectFilipino").value.trim();
//     const subjectMath = _elementId("subjectMath").value.trim();
//     const subjectScience = _elementId("subjectScience").value.trim();
//     const subjectAP = _elementId("subjectAP").value.trim();
//     const subjectEsp = _elementId("subjectEsp").value.trim();
//     const subjectTle = _elementId("subjectTle").value.trim();
//     const subjectMusic = _elementId("subjectMusic").value.trim();
//     const subjectArts = _elementId("subjectArts").value.trim();
//     const subjectPe = _elementId("subjectPe").value.trim();
//     const subjectHealth = _elementId("subjectHealth").value.trim();
//     const subjectEnglish2 = _elementId("subjectEnglish2").value.trim();
//     const subjectFilipino2 = _elementId("subjectFilipino2").value.trim();
//     const subjectMath2 = _elementId("subjectMath2").value.trim();
//     const subjectScience2 = _elementId("subjectScience2").value.trim();
//     const subjectAP2 = _elementId("subjectAP2").value.trim();
//     const subjectEsp2 = _elementId("subjectEsp2").value.trim();
//     const subjectTle2 = _elementId("subjectTle2").value.trim();
//     const subjectMusic2 = _elementId("subjectMusic2").value.trim();
//     const subjectArts2 = _elementId("subjectArts2").value.trim();
//     const subjectPe2 = _elementId("subjectPe2").value.trim();
//     const subjectHealth2 = _elementId("subjectHealth2").value.trim();
//     const subjectEnglish3 = _elementId("subjectEnglish3").value.trim();
//     const subjectFilipino3 = _elementId("subjectFilipino3").value.trim();
//     const subjectMath3 = _elementId("subjectMath3").value.trim();
//     const subjectScience3 = _elementId("subjectScience3").value.trim();
//     const subjectAP3 = _elementId("subjectAP3").value.trim();
//     const subjectEsp3 = _elementId("subjectEsp3").value.trim();
//     const subjectTle3 = _elementId("subjectTle3").value.trim();
//     const subjectMusic3 = _elementId("subjectMusic3").value.trim();
//     const subjectArts3 = _elementId("subjectArts3").value.trim();
//     const subjectPe3 = _elementId("subjectPe3").value.trim();
//     const subjectHealth3 = _elementId("subjectHealth3").value.trim();
//     const subjectEnglish4 = _elementId("subjectEnglish4").value.trim();
//     const subjectFilipino4 = _elementId("subjectFilipino4").value.trim();
//     const subjectMath4 = _elementId("subjectMath4").value.trim();
//     const subjectScience4 = _elementId("subjectScience4").value.trim();
//     const subjectAP4 = _elementId("subjectAP4").value.trim();
//     const subjectEsp4 = _elementId("subjectEsp4").value.trim();
//     const subjectTle4 = _elementId("subjectTle4").value.trim();
//     const subjectMusic4 = _elementId("subjectMusic4").value.trim();
//     const subjectArts4 = _elementId("subjectArts4").value.trim();
//     const subjectPe4 = _elementId("subjectPe4").value.trim();
//     const subjectHealth4 = _elementId("subjectHealth4").value.trim();
//     const x = new XMLHttpRequest();
//     x.onload = function(){
//         _query("[tableName]").innerHTML = this.responseText;
//         _query(".update-grade").close();
//     }
//     x.open("GET","../registrar_re/enroll_student.php?updateGrade&entriesName="+entriesName+"&subjectEnglish="+subjectEnglish+"&subjectFilipino="+subjectFilipino+"&subjectMath="+subjectMath+"&subjectScience="+subjectScience+"&subjectAP="+subjectAP+"&subjectEsp="+subjectEsp+"&subjectTle="+subjectTle+"&subjectMusic="+subjectMusic+"&subjectArts="+subjectArts+"&subjectPe="+subjectPe+"&subjectHealth="+subjectHealth+"&subjectEnglish2="+subjectEnglish2+"&subjectFilipino2="+subjectFilipino2+"&subjectMath2="+subjectMath2+"&subjectScience2="+subjectScience2+"&subjectAP2="+subjectAP2+"&subjectEsp2="+subjectEsp2+"&subjectTle2="+subjectTle2+"&subjectMusic2="+subjectMusic2+"&subjectArts2="+subjectArts2+"&subjectPe2="+subjectPe2+"&subjectHealth2="+subjectHealth2+"&subjectEnglish3="+subjectEnglish3+"&subjectFilipino3="+subjectFilipino3+"&subjectMath3="+subjectMath3+"&subjectScience3="+subjectScience3+"&subjectAP3="+subjectAP3+"&subjectEsp3="+subjectEsp3+"&subjectTle3="+subjectTle3+"&subjectMusic3="+subjectMusic3+"&subjectArts3="+subjectArts3+"&subjectPe3="+subjectPe3+"&subjectHealth3="+subjectHealth3+"&subjectEnglish4="+subjectEnglish4+"&subjectFilipino4="+subjectFilipino4+"&subjectMath4="+subjectMath4+"&subjectScience4="+subjectScience4+"&subjectAP4="+subjectAP4+"&subjectEsp4="+subjectEsp4+"&subjectTle4="+subjectTle4+"&subjectMusic4="+subjectMusic4+"&subjectArts4="+subjectArts4+"&subjectPe4="+subjectPe4+"&subjectHealth4="+subjectHealth4);
//     x.send();
// }
function submitNewUpdateGrade1Cta(){
    const entriesName = _elementId("entriesName").value.trim();
    const updateSubjectEnglish = _elementId("updateSubjectEnglish").value.trim();
    const updateSubjectFilipino = _elementId("updateSubjectFilipino").value.trim();
    const updateSubjectMath = _elementId("updateSubjectMath").value.trim();
    const updateSubjectScience = _elementId("updateSubjectScience").value.trim();
    const updateSubjectAP = _elementId("updateSubjectAP").value.trim();
    const updateSubjectEsp = _elementId("updateSubjectEsp").value.trim();
    const updateSubjectTle = _elementId("updateSubjectTle").value.trim();
    const updateSubjectMusic = _elementId("updateSubjectMusic").value.trim();
    const updateSubjectArts = _elementId("updateSubjectArts").value.trim();
    const updateSubjectPe = _elementId("updateSubjectPe").value.trim();
    const updateSubjectHealth = _elementId("updateSubjectHealth").value.trim();

        const x = new XMLHttpRequest();
        x.onload = function(){
            _query(".update-grade").close();
        }
        x.open("GET","../registrar_re/encode_grades.php?updateName&entriesName="+entriesName+"&updateSubjectEnglish="+updateSubjectEnglish+"&updateSubjectFilipino="+updateSubjectFilipino+"&updateSubjectMath="+updateSubjectMath+"&updateSubjectScience="+updateSubjectScience+"&updateSubjectAP="+updateSubjectAP+"&updateSubjectEsp="+updateSubjectEsp+"&updateSubjectTle="+updateSubjectTle+"&updateSubjectMusic="+updateSubjectMusic+"&updateSubjectArts="+updateSubjectArts+"&updateSubjectPe="+updateSubjectPe+"&updateSubjectHealth="+updateSubjectHealth);
        x.send();
}

